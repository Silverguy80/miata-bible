# Modified Miata Bible — AI coding handoff

This archive contains the current Modified Miata Bible web app as of commit `7d74454`.

## Project

Static browser application for NA, NB, NC, and ND Mazda MX-5 Miatas. It includes a generation-specific repair manual, garage profile, service/modification history, build planner, performance upgrade catalog, dyno/drag estimator, product recommendations, Miata history, and Wheel & Tire Fitment Lab.

## Main files

- `app.js` — application state, rendering, routing, interactions, and manual reader.
- `content.js` — structured generations, procedures, parts, performance data, fitment data, and history.
- `generation-content.js` — generation-specific NA/NB/NC/ND manual content.
- `garage-store.js` — local garage persistence adapter.
- `styles.css` — responsive design system and mobile containment rules.
- `preview.html` — standalone public bundle with inline CSS and JavaScript.
- `index.html` — modular source app shell.
- `assets/` — local generation imagery and illustration assets.
- `docs/` — editorial, coverage, and fitment research notes.

## Run locally

Because the modular app uses ES modules, serve this directory over HTTP rather than opening `index.html` directly:

```bash
python3 -m http.server 4173
```

Then open `http://localhost:4173/`. The standalone `preview.html` can also be opened directly or served from the same directory.

## Important constraints

- Preserve responsive behavior. Mobile text must never run outside the viewport.
- Keep fitment ranges labeled as planning ranges, not universal guarantees.
- Keep original synthesis separate from VIN-specific factory wiring, torque, calibration, or specification data.
- Do not replace the structured manual content with generic filler.
- Run `node --check app.js`, `node --check content.js`, and `git diff --check` after edits.
- Keep `preview.html` synchronized with source changes before publishing.
